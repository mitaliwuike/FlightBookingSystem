﻿using System;

using System.Globalization;

using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace FlightBookingWebApi.Converter
{
    /// <summary>
    /// JsonConverter is used for datatime convert 
    /// </summary>
    public class DateConverter : JsonConverter<DateTime>
    {
        private string formatDate = "dd/MM/yyyy HH:mm:ss";//MM for Month and mm for min
        public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            return DateTime.ParseExact(reader.GetString(), formatDate, CultureInfo.InvariantCulture);
        }

        public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToString(formatDate));
        }
    }
}
